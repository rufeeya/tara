package com.infosys.anz.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.infosys.anz.entity.UsersEntity;

/**
 * 
 * @author RufeeyaTarannum
 *
 * UserRepository - interacts with UserEntity table in database
 */
public interface UserRepository extends JpaRepository<UsersEntity, Integer>{

}
