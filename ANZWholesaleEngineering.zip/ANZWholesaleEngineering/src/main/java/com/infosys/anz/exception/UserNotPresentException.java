package com.infosys.anz.exception;

@SuppressWarnings("serial")

public class UserNotPresentException extends ANZEngineeringException{
	
	public UserNotPresentException(String message) {
		super(message);
	}

}
