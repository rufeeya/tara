package com.infosys.anz.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.infosys.anz.entity.UserAccountsEntity;

/***
 * 
 * @author RufeeyaTarannum
 *
 * UserAccountsRepository - Querying the DB to fetch the accounts list and pass it back to service
 */

@Repository
public interface UserAccountsRepository extends JpaRepository <UserAccountsEntity, Integer>  {
	
	@Query("select a from UserAccountsEntity a where a.userId=:userId")
	List<UserAccountsEntity> getAccounts(@Param("userId") Integer userId);
}
