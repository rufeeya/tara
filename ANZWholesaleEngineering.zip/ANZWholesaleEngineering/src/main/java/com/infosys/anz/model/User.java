package com.infosys.anz.model;

/********
 * 
 * @author RufeeyaTarannum
 * 
 * User model - contains the fields, getters and setters functions for the fields in UserEntity
 *
 */

public class User {

		 	private int userId;
		    private String password;
		    private String name;

		    public int getUserId() {
		        return userId;
		    }
		    public void setUserId(int userId) {
		        this.userId = userId;
		    }
		    public String getPassword() {
		        return password;
		    }
		    public void setPassword(String password) {
		        this.password = password;
		    }
		    public String getName() {
		        return name;
		    }
		    public void setName(String name) {
		        this.name = name;
		    }
	}
