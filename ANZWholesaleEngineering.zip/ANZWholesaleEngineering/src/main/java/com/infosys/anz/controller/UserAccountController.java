package com.infosys.anz.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

import com.infosys.anz.exception.UserNotPresentException;
import com.infosys.anz.model.UserAccounts;
import com.infosys.anz.service.UserAccountsService;


/**
 * 
 * @author RufeeyaTarannum
 * 
 * Controller handle that invokes service method to do the service
 * 
 * Handles thrown exception if user is not present in the system
 *
 */

@Controller
public class UserAccountController {
	
	@Autowired
	UserAccountsService userAccountsService;
	
	@Autowired
	private Environment environment;
	
	private String command = "command";
	private String displayAccounts = "displayAccounts";
	
	@GetMapping("/showAccounts")
	public ModelAndView showAccounts(Model model, @RequestParam("userId") Integer userId, UserAccounts accountList,
			BindingResult bindingResult) {
		
		final Logger logger ;
		
		ModelAndView modelAndView = null;
		
		if (bindingResult.hasErrors()) {
			modelAndView = new ModelAndView(displayAccounts, command, accountList);

		}
		else {
			try {
				   boolean present = userAccountsService.checkUserPresence(userId);
				   
				   if(present) {
					   
					   List<UserAccounts> accounts = userAccountsService.displayAccounts(userId);
						model.addAttribute("accounts", accounts);
						model.addAttribute("userId", userId);
					
						modelAndView = new ModelAndView(displayAccounts, command, accountList);
					   
				   }				
					
				}
				catch(UserNotPresentException e){
					
					logger = LoggerFactory.getLogger(this.getClass());
					
					System.out.println("CATCH: "+e.getMessage()+ "   " + environment.getProperty(e.getMessage()));
					
					if (e.getMessage().contains("UserAccountsService")) {
						modelAndView = new ModelAndView("home"); 
						modelAndView.addObject(command,accountList);
						modelAndView.addObject("message", environment.getProperty(e.getMessage()));
					}
					
					logger.error(e.getMessage(), e);
				}	
		}
		
		return modelAndView;
		
	}

	
}
