package com.infosys.anz.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.anz.entity.UserAccountsEntity;
import com.infosys.anz.exception.UserNotPresentException;
import com.infosys.anz.model.UserAccounts;
import com.infosys.anz.repository.UserAccountsRepository;
import com.infosys.anz.repository.UserRepository;

/****
 * 
 * @author RufeeyaTarannum
 * 
 * Service layer for displaying list of accounts for that particular user (logged in user)
 * 
 * Throws exception if userId is not present in the system
 * 
 */

@Service
public class UserAccountsService {
	
	@Autowired
	UserAccountsRepository userAccountsRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	public List<UserAccounts> displayAccounts(Integer userId) throws UserNotPresentException {
		
		List<UserAccountsEntity> userAccountsEntity = userAccountsRepository.getAccounts(userId);
		
		List<UserAccounts> userAccounts = new ArrayList<>();
		
		for(UserAccountsEntity u :userAccountsEntity) {
			
			UserAccounts account = new UserAccounts();
			
			account.setAccountName(u.getAccountName());
			account.setAccountNumber(u.getAccountNumber());
			account.setAccountType(u.getAccountType());
			account.setBalanceDate(u.getBalanceDate());
			account.setCurrency(u.getCurrency());
			account.setOpeningBalance(u.getOpeningBalance());
			
			userAccounts.add(account);
		}

		return userAccounts;
	}
	
	public boolean checkUserPresence(Integer userId) throws UserNotPresentException{
			
		boolean present = userRepository.existsById(userId);
		
		if(!present) {
			
			throw new UserNotPresentException("UserAccountsService.USER_NOT_PRESENT");
		}
		
		return present;
	}
}
