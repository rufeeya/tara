package com.infosys.anz.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosys.anz.entity.TransactionListEntity;

/***
 * 
 * @author RufeeyaTarannum
 * 
 * TransactionListRepository - Querying the DB to fetch the transaction list and pass it back to service
 *
 */

@Repository
public interface TransactionListRepository extends JpaRepository <TransactionListEntity, Integer>{
	
	@Query("select t from TransactionListEntity t where t.accountNumber=:accountNumber")
	List<TransactionListEntity> getTransactions(@Param("accountNumber") Integer accountNumber);

}








