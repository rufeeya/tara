package com.infosys.com.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.infosys.anz.entity.UserAccountsEntity;
import com.infosys.anz.entity.UsersEntity;
import com.infosys.anz.exception.UserNotPresentException;
import com.infosys.anz.model.User;
import com.infosys.anz.model.UserAccounts;
import com.infosys.anz.repository.UserAccountsRepository;
import com.infosys.anz.repository.UserRepository;
import com.infosys.anz.service.UserAccountsService;

/**
 * 
 * @author RufeeyaTarannum
 * 
 * ServiceTest - takes care of testing service as well as  repository
 *
 */

@RunWith(MockitoJUnitRunner.class)
public class UserAccountsServiceTest {
	
	@InjectMocks
	private UserAccountsService userAccountsService;
	
	@Mock
	private UserAccountsRepository userAccountsRepository;
	
	@Mock
	private UserRepository userRepository;	
	
	UserAccountsEntity userAccountsEntity1 = new UserAccountsEntity();
	UserAccountsEntity userAccountsEntity2 = new UserAccountsEntity();
	
	List<UserAccountsEntity> actual = new ArrayList<UserAccountsEntity>();
	
	User user = new User();
	UsersEntity userEntity = new UsersEntity();
	
	User user1 = new User();
	UsersEntity userEntity1 = new UsersEntity();
	
	
	@Before
	public void initialWork() {
		
		/* Initializations to test getAccounts() */
		
		userAccountsEntity1.setAccountNumber(585309209);
		userAccountsEntity1.setAccountName("SGSavings726");
		userAccountsEntity1.setAccountType("Savings");
		userAccountsEntity1.setBalanceDate(new Date());
		userAccountsEntity1.setCurrency("SGD");
		userAccountsEntity1.setOpeningBalance((float)84327.51);
		
		userAccountsEntity2.setAccountNumber(123456789);
		userAccountsEntity2.setAccountName("dummy");
		userAccountsEntity2.setAccountType("dummy");
		userAccountsEntity2.setBalanceDate(new Date());
		userAccountsEntity2.setCurrency("dummy");
		userAccountsEntity2.setOpeningBalance(00000);
		
		actual.add(userAccountsEntity1);
		actual.add(userAccountsEntity2);
		
		/* Initializations to test checkUserPresence() */

		user.setUserId(1420);
		userEntity.setUserId(user.getUserId());
			
		user1.setUserId(1234);
		userEntity1.setUserId(user1.getUserId());
		
	}
	
	@Test
	public void testGetAccountsPositive() throws UserNotPresentException {
		
		when(userAccountsRepository.getAccounts(1420)).thenReturn(actual);
		
		List<UserAccounts> expected = userAccountsService.displayAccounts(1420);
		
		assertEquals(2,expected.size());
		
		verify(userAccountsRepository, times(1)).getAccounts(1420);
			
	}
	
	@Test
	public void testGetAccountsNegative() throws UserNotPresentException {
		
		when(userAccountsRepository.getAccounts(1420)).thenReturn(actual);
		
		List<UserAccounts> expected = userAccountsService.displayAccounts(1234);
		
		System.out.println(expected.size());
		
		assertNotEquals(2,expected.size());
		
		assertNotSame(userAccountsRepository.getAccounts(1420),expected);
			
	}
	

	@Test
	public void testUserPositive() {
		
		Mockito.when(userRepository.existsById(user.getUserId())).thenReturn(true);
		try {
			
				boolean present = userAccountsService.checkUserPresence(user.getUserId());
				
				assertEquals(present,true);
				
			}catch(Exception e) {
				
				Assert.fail("Exception: "+e);
		}
		
	}

	@Test
	public void testUserNegative() throws UserNotPresentException {
		
		String expectedMessage = "UserAccountsService.USER_NOT_PRESENT";
		
		Mockito.when(userRepository.existsById(user1.getUserId())).thenReturn(false);
		
		Exception e = assertThrows(UserNotPresentException.class, () -> {userAccountsService.checkUserPresence(user1.getUserId());});
		
	    String actualMessage = e.getMessage();
	 
	    assertTrue(actualMessage.contains(expectedMessage));
		
	}

}
